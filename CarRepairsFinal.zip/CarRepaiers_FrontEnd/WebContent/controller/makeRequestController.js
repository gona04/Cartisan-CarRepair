/**
 * 
 */
app.controller('makeARequestController',function($scope,$location,RepairRequestService)
{

	//TO SEND A REQUEST FOR THE LOGGED IN CAROWNER
		$scope.makeARequest = function() 
		{
				console.log('in makeArequest method');
				RepairRequestService.sendRequest($scope.request).then(function(response)
		{
				console.log(response.data);
				/*$scope.success = "Request sent successfully! We will get back to you soon";*/
                alert('Thank you for making a request! We will soon get back to you ! ');
				$location.path('/getUserRequest');
		},
		function(response)
		{
				console.log(response.data);
				$scope.error = response.data;
				$location.path('/login');
		})
		}
	
})
