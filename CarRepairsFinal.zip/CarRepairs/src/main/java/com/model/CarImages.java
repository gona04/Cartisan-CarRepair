package com.model;

import javax.persistence.*;

@Entity
public class CarImages 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int imageId;
	@Lob
	private byte[] image;
	
	@ManyToOne
	private RepairRequests requestId;
	
	
	public int getImageId() 
	{
		return imageId;
	}
	public void setImageId(int imageId)
	{
		this.imageId = imageId;
	}
	public byte[] getImage() 
	{
		return image;
	}
	public void setImage(byte[] image) 
	{
		this.image = image;
	}
	public RepairRequests getRequestId() 
	{
		return requestId;
	}
	public void setRequestId(RepairRequests requestId) 
	{
		this.requestId = requestId;
	}
}
