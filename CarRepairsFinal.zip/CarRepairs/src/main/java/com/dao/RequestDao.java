package com.dao;

import java.util.List;

import com.model.RepairRequests;

public interface RequestDao 
{
	void saveRequest(RepairRequests request);
	List<RepairRequests> getAllRequests();
	List<RepairRequests> getRequestByName(String username);
	void responseFromWrokshop(RepairRequests request);
	RepairRequests getRequestById(int id);
	void checkViewedStatus();
}
