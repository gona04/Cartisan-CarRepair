package com.dao;

import com.model.Customers;
import com.model.Error;

public interface CustomerDao 
{
	void registerUser(Customers customer);
	boolean isValidEmail(String email);
	boolean isValidUsername(String name);
	boolean isValidPassword(String password);
	Customers login(Customers customer);
	
	Customers getDetailsByUserName(String username);
}
