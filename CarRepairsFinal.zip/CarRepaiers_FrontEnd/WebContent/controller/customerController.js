/**
 * 
 */
console.log('in CustomerController.js');

app.controller('CustomerController', function(CustomerService, $scope,$location,$rootScope,$cookieStore)
		{
	
			$scope.customer = {};
			
			//FOR REGISTRATION
			$scope.registeration = function()
			{
				//console.log('in registration method of CustomerController.js');
				CustomerService.regestration($scope.customer).then(function(response)
						{
							console.log(response.data);
							$scope.success="Registered Successfully";
							$location.path('/login');
						},
						function(response)
						{
							console.log(response.data);
							$scope.error = response.data;
							if($scope.error.code == 1 || $scope.error.code == 2)
								{
									$scope.pe = response.data;
								}
							if($scope.error.code == 3)
							{
								$scope.email = response.data;
							}
							if($scope.error.code == 4)
							{
								$scope.name = response.data;
							}
							if($scope.error.code == 5)
							{
								$scope.internal = response.data;
							}
							$location.path('/register');
						})
			}
			
			
			//FOR LOGIN
			$scope.login = function()
			{
				CustomerService.login($scope.customer).then(function(response)
						{
							$rootScope.currentUser = response.data;
							$cookieStore.put("currentUser",response.data);
							$location.path('/home');
							console.log($rootScope.currentUser);
						},
						function(response)
						{
							$scope.loginError = response.data;
							$location.path('/login');
						})
						
						console.log('in login customer');
			}
 		})