/**
 * 
 */
app.factory('RepairRequestService',function($http)
		{
			var repairRequestService = {};
			var BASE_URL = "http://localhost:3031/CarRepairs/";
			console.log('in repair request service')
			
			//TO SAVE A REQUEST FROM THE LOGGED IN CAROWNER
			repairRequestService.sendRequest = function(request)
			{
				console.log('in repair request service send request method')
				return $http.post(BASE_URL+"/sendRequest",request);
			}
			
			//TO GET ALL THE REQUESTS FOR THE WORKSHOP USERS
			repairRequestService.getAllRequests = function()
			{
				console.log('Request Service- Get All Requests');
				return $http.get(BASE_URL + "/getAllRequests");
			}
			
			//TO GET A SPECIFIC REQUEST! 
			repairRequestService.getRequestById = function(id)
			{
				console.log('getRequestById service');
				console.log(id);
				return $http.get(BASE_URL+"/getRequestById/" +id);			
			}
			
			//TO REGISTER UPDATES RECIEVED FROM THE WORKSHOP
			repairRequestService.updatequotation = function(quotation)
			{
				console.log(quotation);
				return $http.put(BASE_URL + "/updateReplay",quotation);
			}
			
			//FOR THE CUSTOMER TO GET THE PERSONAL LIST OF THEIR COMPLAINS
			repairRequestService.getUserRequest = function()
			{
				console.log('getting each users request');
				return $http.get(BASE_URL+"/personalRequests");
			}
			return repairRequestService;
		})