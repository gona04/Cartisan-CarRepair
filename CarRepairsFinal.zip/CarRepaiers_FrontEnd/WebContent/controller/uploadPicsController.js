/**
 * 
 */
app.controller('uploadPicsController',function($scope,$location,$routeParams)
		{
			console.log($routeParams.id);
			var BASE_URL = "http://localhost:3031/CarRepairs/uploadImages/"
			$scope.full_URL = BASE_URL + $routeParams.id;
			console.log($scope.full_URL);
			return $location.path('/uploadPictures');
		});