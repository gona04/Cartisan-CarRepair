/**
 * 
 */

app.controller('userRequestController',function($scope,RepairRequestService,$location,$routeParams)
		{
			function getUserRequest()
			{
				RepairRequestService.getUserRequest().then(function(response)
						{
							console.log(response.data);
							$scope.userRequests = response.data;
							$location.path('/getUserRequest');
						},
						function(response)
						{
							console.log(response.data);
							$scope.UserError = response.data;
							$location.path('/login');
						})
			}
			
			getUserRequest();
		})