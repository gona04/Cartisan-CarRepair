package com.dao;

import com.model.CarImages;

public interface CarImagesDao 
{
	 void saveImages(CarImages carImages);
}
