/**
 * 
 */

app.controller('RepairRequestController', function(RepairRequestService, $scope, $location)
{
		
		$scope.request = {};
		console.log('in rrController');
		
		//GET ALL USERS FOR THE WORKSHOP USERS
		function getAllRequests()
		{
			RepairRequestService.getAllRequests().then(function(response)
					{
						console.log(response.data);
						$scope.requests = response.data;
						$location.path('/getAllRequests');
					},
					function(response)
					{
						console.log(response.data);
						$scope.requestsError = response.data;
						$location.path('/home');
					})
		}
		

	getAllRequests();
});