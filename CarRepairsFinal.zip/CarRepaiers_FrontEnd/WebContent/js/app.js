/**
 * 
 */
console.log('in app.js')
var app = angular.module('mainApp',['ngRoute','ngCookies']);
app.config(function($routeProvider)
		{
			console.log('in the routeProvider method of app.js')
			$routeProvider
			.when('/home',
					{
						templateUrl:'views/home.html'
					})
			.when('/register',
					{
						templateUrl:'views/registrationForm.html',
						controller:'CustomerController'
					})
			.when('/login',
					{
						templateUrl:'views/login.html',
						controller:'CustomerController'
					})
			.when('/makeARequest',
					{
						templateUrl:'views/saveARequest.html',
						controller:'makeARequestController'
					})
			.when('/getAllRequests',
					{
						templateUrl:'views/getAllRequests.html',
						controller:'RepairRequestController'
					})
			.when('/updateReplay/:id',
					{
						templateUrl:'views/requestUpdate.html',
						controller:'RepairRequestDetailsController'
					})
			.when('/uploadPics/:id',
					{
						controller:"uploadPicsController"
					})
			.when('/uploadPictures',
					{
						templateUrl:'views/uploadImages.html'
					})
			.when('/getUserRequest',
			{
				templateUrl:'views/UR.html',
				controller:'userRequestController'
			})
		})
		
app.run(function($rootScope,$cookieStore,CustomerService,$location)
		{
	if($rootScope.currentUser==undefined)
		$rootScope.currentUser=$cookieStore.get("currentUser")
		
		$rootScope.logout=function(){
		CustomerService.logout().then(function(response){
        	$rootScope.logoutSuccess="Logged out Successfully.."
        		delete $rootScope.currentUser
        		$cookieStore.remove("currentUser")
        		$location.path('/login');
        },function(response){
        	$scope.error=response.data
        	$location.path('/login')
        })		
	}		
			
		})