/**
 * 
 */
app.factory('CustomerService', function($http)
		{
			console.log('in customer Service method');
			var customerService= {};
			var BASE_URL = "http://localhost:3031/CarRepairs/";
			
			//FOR REGISTRATION OR SIGNUP
			customerService.regestration = function(customer)
			{
				//console.log('in customer service registration method');
				return $http.post(BASE_URL+'/register',customer);
			}
			
			//FOR LOGIN
			customerService.login = function(customer)
			{
				//console.log('in customer service login method');
				return $http.post(BASE_URL+'/login',customer);
			}
			
			//FOR LOGOUT
			customerService.logout = function()
			{
				return $http.get(BASE_URL+'/logout');
			}
			return customerService;
		});