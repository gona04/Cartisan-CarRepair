package com.controller;

import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dao.CustomerDao;
import com.dao.RequestDao;
import com.model.Customers;
import com.model.Error;
import com.model.RepairRequests;

@Controller
public class RepairRequestsController
{
	@Autowired
	CustomerDao cdao;
	@Autowired
	RequestDao rdao;
	
	//FOR CUSTOMER'S TO SEND THE REPAIR REQUEST
	@RequestMapping(value="/sendRequest", method=RequestMethod.POST)
	public ResponseEntity<?> saveRequest(@RequestBody RepairRequests request, HttpSession session)
	{
		String userName = (String)session.getAttribute("username");
		if(userName == null)
		{
			Error error = new Error(6,"Please login before sending a request!");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED);
		}
		
		System.out.println(userName);
		Customers requestedBy = cdao.getDetailsByUserName(userName);
		
		System.out.println(requestedBy.getVehicleModel());
		request.setRequestedBy(requestedBy);
		//request.setVehicleModel(requestedBy.getVehicleModel());
		request.setRequestedOn(new Date());
		rdao.saveRequest(request);
		return new ResponseEntity<RepairRequests>(request,HttpStatus.OK);
	}
	
	//GET THE CAROWNER'S REQUEST TO THE CAR OWNER
	@RequestMapping("/personalRequests")
	public ResponseEntity<?>getPersonalRequests(HttpSession session)
	{
		String userName = (String)session.getAttribute("username");
		Customers validateRole = cdao.getDetailsByUserName(userName);
		
		if(userName == null)
		{
			Error error = new Error(6,"Please login as a valid user");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED);
		}
		
		List<RepairRequests> personalRequests = rdao.getRequestByName(userName);
		return new ResponseEntity<List<RepairRequests>>(personalRequests,HttpStatus.OK);
	}
	
	
	
	//FOR wORKSHOP USERS TO SEE ALL THE REQUESTS!
	@RequestMapping("/getAllRequests")
	public ResponseEntity<?> getAllRequests(HttpSession session)
	{
		String userName = (String) session.getAttribute("username");
		Customers validateRole = cdao.getDetailsByUserName(userName);
		
		if(userName == null)
		{
			Error error = new Error(6,"Please login as a valid user");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED);
		}
		
		List<RepairRequests> requests = rdao.getAllRequests();
		return new ResponseEntity<List<RepairRequests>>(requests,HttpStatus.OK);
	}
	
	
	//TO GET A SPECIFIC REQUEST
	@RequestMapping("/getRequestById/{id}")
	public ResponseEntity<?> getRequestById(@PathVariable int id,HttpSession session)
	{
		String userName = (String) session.getAttribute("username");
		Customers validateRole = cdao.getDetailsByUserName(userName);
		
		if(userName == null)
		{
			Error error = new Error(6,"Please login as a valid user");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED);
		}
		
		RepairRequests request = rdao.getRequestById(id);
		
		return new ResponseEntity<RepairRequests>(request,HttpStatus.OK);
	}
	
	//TO UPDATE THE REPLAY RECIEVED FROM THE WORKSHOP USERS
	@RequestMapping(value="/updateReplay",method=RequestMethod.PUT)
	public ResponseEntity<?> updateReplay(@RequestBody RepairRequests request,HttpSession session)
	{
		String userName = (String) session.getAttribute("username");
		Customers validateRole = cdao.getDetailsByUserName(userName);
		
		if(userName == null)
		{
			Error error = new Error(6,"Please login as a valid user");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED);
		}
		rdao.checkViewedStatus();
		rdao.responseFromWrokshop(request);
		return new ResponseEntity<RepairRequests>(request,HttpStatus.OK);
	}
}
