package com.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.model.Error;
import com.dao.CustomerDao;
import com.model.Customers;

@Controller
public class CustomerController 
{
	@Autowired
	CustomerDao cdao;
	
	//FOR REGISTRATION OF THE CAROWNER
	@RequestMapping(value="/register", method=RequestMethod.POST)
	public ResponseEntity<?> registeration(@RequestBody Customers customer)
	{
		System.out.println("in registeration method");
		if(!cdao.isValidEmail(customer.getEmailId()))
		{
			System.out.println("email method of controller");
			Error error = new Error(3,"Email Id already exisists");
			return new ResponseEntity<Error>(error,HttpStatus.NOT_ACCEPTABLE);
		}
		
		if(!cdao.isValidUsername(customer.getName()))
		{
			System.out.println("username method of controller");
			Error error = new Error(4,"Name already exsists");
			return new ResponseEntity<Error>(error,HttpStatus.NOT_ACCEPTABLE);
		}
		
		if(!customer.getPassword().equals(customer.getConfirmPassword()))
		{
			System.out.println("Password Mismatch...."+" "+customer.getPassword()+""+customer.getConfirmPassword());
			Error error = new Error(2,"Both the passwords Do not match!");
			return new ResponseEntity<Error>(error,HttpStatus.NOT_ACCEPTABLE);
		}
		else if(cdao.isValidPassword(customer.getPassword()))
		{
			System.out.println("password method of controller");
			Error error = new Error(1,"password cannot be empty");
			return new ResponseEntity<Error>(error,HttpStatus.NOT_ACCEPTABLE);
		}
		
		try
		{
			System.out.println("registering customer in controller");
			customer.setRole("CAROWNER_USER");
			cdao.registerUser(customer);
			return new ResponseEntity<Customers>(customer,HttpStatus.OK);
		}
		catch(Exception e)
		{
			System.out.println("catch block of controller");
			Error error = new Error(5,"Unable to register");
			return new ResponseEntity<Error>(error,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
	}
	
	//FOR THE LOGIN OF BOTH THE CAROWNER AND THE WORKSHOP USERS
	@RequestMapping(value="/login",method=RequestMethod.POST)
	public ResponseEntity<?> login(@RequestBody Customers customer,HttpSession session)
	{
		Customers validCustomer = cdao.login(customer);
		
		if(validCustomer == null)
		{
			Error error = new Error(6,"Invalid emailId and password");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED);
		}
		System.out.println(customer.getEmailId()+"   "+ customer.getPassword()+"\n"+"valid user"+validCustomer.getName());
		session.setAttribute("username", validCustomer.getName());
		
		return new ResponseEntity<Customers>(validCustomer,HttpStatus.OK);
	}
	
	//FOR LOGGING OUT
	@RequestMapping("/logout")
	public ResponseEntity<?> logout(HttpSession session)
	{
		if(session.getAttribute("username")== null)
		{
			Error error = new Error(7,"User not logged in");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED);
		}
		session.removeAttribute("username");
		session.invalidate();
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
