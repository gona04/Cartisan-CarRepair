/**
 * 
 */
app.controller('RepairRequestDetailsController',function(RepairRequestService, $scope, $location,$routeParams)
		{
	
			var id = $routeParams.id;
			console.log(id);
			
			//TO GET REQUEST BY ID
				RepairRequestService.getRequestById(id).then(function(response)
				{
					$scope.rRequest = response.data;
					console.log(response.data);
				},
				function(response)
				{
					$scope.sr_error = response.data;
					console.log(response.data);
					$location.path('/login');
				})
			
			$scope.updateQuotation = function()
			{
				RepairRequestService.updatequotation($scope.rRequest).then(function(response)
						{
							$location.path('/getAllRequests');
						},
						function(response)
						{
							if(response.status == 401)
							{
								$location.path('/login')
							}
						$location.path('/updateReplay/' + id);
						})
			}
			
			
		})