package com.model;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;

@Entity
public class RepairRequests 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int requestId;
	@Lob
	private String description;

	@ManyToOne
	@JoinTable(name="requestedBy")
	private Customers requestedBy;
	private Date requestedOn;
	private double quotation;
	private String remarksByWorkshop;
	private boolean viewedStatus;

	public int getRequestId() 
	{
		return requestId;
	}

	public void setRequestId(int requestId) 
	{
		this.requestId = requestId;
	}

	public String getDescription()
	{
		return description;
	}

	public void setDescription(String description) 
	{
		this.description = description;
	}

	public Customers getRequestedBy() 
	{
		return requestedBy;
	}

	public void setRequestedBy(Customers requestedBy) 
	{
		this.requestedBy = requestedBy;
	}
	
	public double getQuotation() {
		return quotation;
	}

	public void setQuotation(double quotation) {
		this.quotation = quotation;
	}

	public String getRemarksByWorkshop()
	{
		return remarksByWorkshop;
	}

	public void setRemarksByWorkshop(String remarksByWorkshop)
	{
		this.remarksByWorkshop = remarksByWorkshop;
	}

	public Date getRequestedOn() 
	{
		return requestedOn;
	}

	public void setRequestedOn(Date requestedOn)
	{
		this.requestedOn = requestedOn;
	}

	public boolean isViewedStatus() 
	{
		return viewedStatus;
	}

	public void setViewedStatus(boolean viewedStatus) 
	{
		this.viewedStatus = viewedStatus;
	}
	
	
}
