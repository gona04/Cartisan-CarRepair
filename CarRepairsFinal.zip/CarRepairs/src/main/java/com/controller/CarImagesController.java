package com.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.dao.CarImagesDao;
import com.dao.CustomerDao;
import com.dao.RequestDao;
import com.model.CarImages;
import com.model.RepairRequests;

@Controller
public class CarImagesController 
{
	@Autowired
	CarImagesDao carImagesDao;
	@Autowired
	CustomerDao cdao;
	@Autowired
	RequestDao rdao;
	
	@RequestMapping(value="/uploadImages/{id}", method=RequestMethod.POST)
	public ResponseEntity<?> saveImages(@RequestParam CommonsMultipartFile image,HttpSession session,@PathVariable int id)
	{
		System.out.println("in upload images method");
		String username = (String)session.getAttribute("username");
		if(cdao.getDetailsByUserName(username) == null)
		{
			Error error = new Error("Unauthorized User");
			return new ResponseEntity<Error>(error,HttpStatus.UNAUTHORIZED);
		}
		
		RepairRequests forRequest = rdao.getRequestById(id);
		CarImages carImage = new CarImages();
		carImage.setRequestId(forRequest);
		carImage.setImage(image.getBytes());
		carImagesDao.saveImages(carImage);
		//JUST REMEMBER WE HAVE DONE SOMETHING UNUSUAL HERE IF THERE ARE ANY ERROR FIRST CHECK HERE
		return new ResponseEntity<RepairRequests>(forRequest,HttpStatus.OK);
	}
}
