package com.daoImpl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.model.Error;
import com.dao.CustomerDao;
import com.model.Customers;

@Repository
public class CustomerDaoImpl implements CustomerDao
{

	@Autowired
	SessionFactory sessionFactory;
	
	@Transactional
	public void registerUser(Customers customer)
	{
		System.out.println("In registration daoImpl");
		Session session = sessionFactory.getCurrentSession();
		session.save(customer);
		session.flush();
	}

	@Transactional
	public boolean isValidEmail(String email) 
	{
		System.out.println("Validating email....." + email);
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Customers where emailId = ?");
		query.setString(0, email);
		Customers customer = (Customers) query.uniqueResult();
		if (customer == null)
		{
			System.out.println("True email id");
			return true;
		}
		else
		{
			System.out.println("False email id");
		return false;
		}
	}

	@Transactional
	public boolean isValidUsername(String name) 
	{
		System.out.println("Validating name" + name);
		Session session = sessionFactory.getCurrentSession();
		Customers customer = (Customers) session.get(Customers.class, name);
		
		if(customer == null)
		{
			System.out.println("valid name");
			return true;
		}
		
		else
		{
			System.out.println("invalid name");
			return false;
		}
	}

	@Transactional
	public boolean isValidPassword(String password) 
	{
		System.out.println("Validating Password....." + password);
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Customers where password=?");
		query.setString(0, password);
		
		Customers customer = (Customers) query.uniqueResult();
		
		
		if(customer == null)
		{
			System.out.println("false password");
			return false;
		}
		
		else
		{
			System.out.println("false password");
			return true;
		}
	}

	@Transactional
	public Customers login(Customers customer) 
	{
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Customers where emailId=? and password=?");;
		query.setString(0, customer.getEmailId());
		query.setString(1, customer.getPassword());
		return (Customers) query.uniqueResult();
	}

	//TO GET THE USERDETAILS FOR REQUESTS MADE
	@Transactional
	public Customers getDetailsByUserName(String username) 
	{
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from Customers where name=?");
		query.setString(0, username);
		return (Customers) query.uniqueResult();
	}
	
}
