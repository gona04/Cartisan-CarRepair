package com.daoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dao.CarImagesDao;
import com.model.CarImages;

@Repository
public class CarImagesDaoImpl implements CarImagesDao
{
	@Autowired
	SessionFactory sessionFactory;
	
	@Transactional
	public void saveImages(CarImages carImage) 
	{
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(carImage);
		session.flush();
	}

}
