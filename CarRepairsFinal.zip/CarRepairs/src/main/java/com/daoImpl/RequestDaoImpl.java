package com.daoImpl;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.dao.RequestDao;
import com.model.RepairRequests;

@Repository
public class RequestDaoImpl implements RequestDao 
{
	@Autowired
	SessionFactory sessionFactory;
	
	
	@Transactional
	public void saveRequest(RepairRequests request) 
	{
		Session session = sessionFactory.getCurrentSession();
		session.save(request);
		session.flush();
	}

	@Transactional
	public List<RepairRequests> getAllRequests() 
	{
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from RepairRequests");
		List<RepairRequests> requests =  query.list();
		return requests;
	}

	@Transactional
	public List<RepairRequests> getRequestByName(String username)
	{
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from RepairRequests where requestedBy.name=?");
		query.setString(0, username);
		return query.list();
	}

	@Transactional
	public void responseFromWrokshop(RepairRequests request)
	{
		Session session = sessionFactory.getCurrentSession();
		session.update(request);
		session.flush();
	}

	@Transactional
	public RepairRequests getRequestById(int id)
	{
		Session session = sessionFactory.getCurrentSession();
		Query query = session.createQuery("from RepairRequests where requestId=?");
		query.setInteger(0, id);
		RepairRequests request = (RepairRequests) query.uniqueResult();
		return request;
	}

	@Transactional
	public void checkViewedStatus() 
	{
		Session session = sessionFactory.getCurrentSession();
	
		Query query = session.createQuery("from RepairRequests where quotation != null or remarksByWorkshop != null");
		List<RepairRequests> requests = (List<RepairRequests>) query.list();
		
		for(RepairRequests request: requests)
		{
			request.setViewedStatus(true);
		}
			
	}

	
	
}
